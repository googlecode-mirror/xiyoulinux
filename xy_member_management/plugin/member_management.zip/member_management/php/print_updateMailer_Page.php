<?php
/*
 * File Name:	print_updateMailer_Page.php
 * Author:		Johnson Wei
 * Version:		1.00
 * Description: 修改邮件发送服务器参数
 */
?>

<div class=wrap>
	<h2>邮件服务器设置(Gmail)</h2>
	<br/>
	<form name="form2" action="<?php echo $_SERVER['REQUEST_URI'] ?>" method="post">
		<input type="hidden" name="flag"/>
		<table>
			<tr>
				<td>用户名</td>
				<td><input type="text" name="UserName" value="<?php echo $devOptions['UserName'];?>"/></td>
				<td><font color="color">&nbsp;&nbsp;格式: example@gmail.com</font></td>
			</tr>
			<tr>
				<td>密码</td>
				<td><input type="password" name="Password" value="<?php echo $devOptions['Password']?>"/></td>
			</tr>
			<tr>
				<td>确认密码</td>
				<td><input type="password" name="Password_Confirm"/></td>
				<td><font color="color">&nbsp;&nbsp;若不修改密码，则不需填写</font></td>
			</tr>
			<tr>
				<td>发件人地址</td>
				<td><input type="text" name="From" value="<?php echo $devOptions['From'];?>"/></td>
				<td><font color="color">&nbsp;&nbsp;格式: example@gmail.com</font></td>
			</tr>
			<tr>
				<td>发件人姓名</td>
				<td><input type="text" name="FromName" value="<?php echo $devOptions['FromName'];?>"/></td>
			</tr>
		</table>
		<br/>
		<div class="submit">
			<input type="button" value="提交更改" onclick="check()"/>
		</div>
	</form>
</div>