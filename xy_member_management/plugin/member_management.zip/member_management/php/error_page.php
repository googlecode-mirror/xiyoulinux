<html>
	<head>
		<title>出错了</title>
	</head>
	<body>

			<h2><font color="red">出错啦~</font></h2>
			
			可能由于以下原因: <br/>
			<font color="red"><?php echo $error?></font>

	</body>
</html>