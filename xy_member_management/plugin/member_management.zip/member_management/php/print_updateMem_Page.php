<?php
/*
 * File Name:	print_updateMem_Page.php
 * Author:		Johnson Wei
 * Version:		1.00
 * Description:	输出成员信息列表
 */
?>
<style type="text/css">
<!--

table {
 border-collapse:collapse;
 background:#fff;
 margin:5px 0 10px;
 border:1px solid #d6d6d6;
}
table thead tr th,
table thead tr td {
 background:#c2c2c2;
}
table tr th {
 border: 1px solid #d6d6d6;
 text-align:left;
 padding:5px 10px;
 background:#e6eae9;
}
table tr td {
 border:1px solid #d6d6d6;
 text-align:left;
 vertical-align:middle;
 padding:5px 10px;
 background:#fff;
}

-->
</style>
<?php 
$con = mysql_connect($server, $userName, $password);
if (!$con) {
	die("数据库连接失败" . mysql_error());
}
mysql_query("set name 'utf8'");
mysql_select_db("xiyoulinux");

if (isset($_POST["hidden"])) { // 如果提交到本页
	$modify = $_POST['modify'];
	if (is_array($modify)) {
		foreach($modify as $key) {
			mysql_query("delete from xy_member where member_name = '" . $key . "'");
		}
	} else {
		mysql_query("delete from xy_member where member_name = '" . $modify . "'");
	}
}

$result = mysql_query("select * from xy_member");
//mysql_close($con);
$count = 1;
?>
<div class="wrap">
<h2>成员管理</h2>
<form action="<?php echo $_SERVER['REQUEST_URI']?>" name="form3" method="post">
<input type="hidden" name="hidden"/>
<table border='1'>
	<thead>
		<tr>
			<th><input type="checkbox" name="all" onclick="check_all(this,'modify[]')" /></th>
			<th>序号</th><th>登录名</th><th>真实姓名</th><th>邮箱</th><th>博客</th><th>rss地址</th><th>QQ</th>
			<th>手机</th><th>专业</th>
		</tr>
	</thead>
		<?php
			$pagesize = 5;  //定义每页显示多少条记录
			$page = isset($_GET["page1"])?intval($_GET["page1"]):1;   //定义page的初始值,如果get 传过来的page为空,则page=1,
			$total=mysql_num_rows(mysql_query("select * from xy_member"));  //执行查询获取总记录数
			$pagecount=ceil($total/$pagesize);  //计算出总页数
			if ($page>$pagecount){
				$page=$pagecount;  // 对提交过来的page做一些检查
			}
			if ($page <= 0) {
				$page=1;                   // 对提交过来的page做一些检查
			}
			$offset=($page-1)*$pagesize;   //偏移量
			$pre=$page-1;           //上一页
			$next=$page+1;         //下一页
			$first=1;                       //第一页
			$last=$pagecount;    //末页
			$exec="select * from xy_member order by member_id asc limit $offset,$pagesize"; //执行查询
			$result=mysql_query($exec);
			while ($row=mysql_fetch_array($result)){  //循环出记录
			?>
				<tr>
					<th><input type="checkbox" name="modify[]" value="<?php echo $row['member_name']?>"/></th>
					<td><?php echo $count++;?></td>
					<td><?php echo $row['member_name']?></td><td><?php echo $row['member_nickname']?></td>
					<td><?php echo $row['member_mail']?></td><td><?php echo $row['member_blog']?></td>
					<td><?php echo $row['member_rss_url']?></td><td><?php echo $row['member_QQ']?></td>
					<td><?php echo $row['member_mobile']?></td><td><?php echo $row['member_major']?></td>
				</tr>
			<?php 	
			}
			mysql_close($con);   //关闭数据库连接 
		?>
	</table>
	<div class="submit">
	<input type="button" value="删除" onclick="checkSelect()"/>&nbsp;&nbsp;&nbsp;
	<!-- <input type="button" value="编辑" onclick="checkSelect()"/> -->
	</div>
</form>
第<?php echo $page;?>页 &nbsp;&nbsp;
共<?php echo $pagecount;?>页&nbsp;&nbsp;
<a href="<?php echo $_SERVER['REQUEST_URI'];?>&page1=1">首页</a>&nbsp;
<a href="<?php echo $_SERVER['REQUEST_URI'];?>&page1=<?php echo $pre?>">上一页</a>&nbsp;
<a href="<?php echo $_SERVER['REQUEST_URI'];?>&page1=<?php echo $next?>">下一页</a>&nbsp;
<a href="<?php echo $_SERVER['REQUEST_URI'];?>&page1=<?php echo $last?>">末页</a>
</div>