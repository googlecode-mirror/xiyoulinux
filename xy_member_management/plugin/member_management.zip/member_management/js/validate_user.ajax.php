<?php
/*
 * File Name:	validate_user.ajax.php
 * Author:		Johnson Wei
 * Version:		1.00
 * Description:	这个文件是AJAX代码，检查成员是否存在、发送邮件
 */
	
if (!function_exists('add_action')) {	// 定位wp目录
	require_once('../../../../wp-config.php');
}
?>

var xmlHttp;
var url;

function ajaxFunction(mailAddresses, phpValue) {
	xmlHttp = GetXmlHttpObject();
	if (xmlHttp == null) {
		alert("您的浏览器不支持AJAX！");
		return;
	}
	url = "<?php echo WP_PLUGIN_URL  . '/member_management/js/backstage.php'?>";
	url = url + "?" + phpValue + "=" + mailAddresses;
	url = url + "&sid=" + Math.random();
	xmlHttp.onreadystatechange = stateChanged;
	xmlHttp.open("GET", url, true);
	xmlHttp.send(null);
}

function sendEmail() {
	document.getElementById("txtHint").innerHTML="<font color='red' size='3'>邮件正在发送中，请耐心等待...</font>";
	document.form1.submit();
}

function checkSelect() {
	var theForm = document.form3;
	var radio = document.getElementsByName("modify[]");
	var flag = false;
	for(var i = 0; i < radio.length; i++) {
		if (radio[i].checked)
		flag = true;
	}
	if (!flag) {
		alert("未选中任何项！");
	} else {
		theForm.submit();
	}
}

function check_all(obj,cName) {
    var checkboxs = document.getElementsByName(cName);
    for(var i=0;i < checkboxs.length; i++) {
    	checkboxs[i].checked = obj.checked;
    }
}

function check() {
	var theForm = document.form2;
	var user_name = theForm.UserName.value.replace(/^\s+/,"");
	var pwd = theForm.Password.value.replace(/^\s+/,"");
	var pwd_cfm = theForm.Password_Confirm.value.replace(/^\s+/,"");
	var f = theForm.From.value.replace(/^\s+/,"");
	var fm = theForm.FromName.value.replace(/^\s+/,"");
	if (user_name == "") {
		alert("用户名不能为空！");
	} else if ((pwd_cfm != "") && (pwd != pwd_cfm)) {
		alert("两次密码不一致！");
	} else if (f == "") {
		alert("发件人邮箱不能为空！");
	} else if (fm == "") {
		alert("发件人姓名不能为空！");
	} else {
		theForm.submit();
	}
}

function stateChanged()
{ 
	if (xmlHttp.readyState == 4)
	{
		document.getElementById("txtHint").innerHTML=xmlHttp.responseText;
	}
}

function GetXmlHttpObject()
{
	var xmlHttp=null;
	try {
	  // Firefox, Opera 8.0+, Safari
	  xmlHttp=new XMLHttpRequest();
	} catch(e) {
	  // Internet Explorer
	  try {
	    xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
	  } catch(e) {
	    xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	}
	return xmlHttp;
}