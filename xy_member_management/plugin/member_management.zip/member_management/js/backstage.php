<?php
/*
 * File Name:	backstage.php
 * Author:		Johnson Wei
 * Version:		1.00
 * Description:	这个文件是AJAX后台服务代码
 */
require("../DB-config.php"); // 引入数据库配置

if (!function_exists('add_action')) {	// 定位wp目录
	require_once('../../../../wp-config.php');
}

$dbLink = mysql_connect($server, $userName, $password); // 连接数据库
if (!$dbLink) {
	die("数据库连接失败： " . mysql_error());
}
mysql_query("set names 'utf8'");
mysql_select_db('xiyoulinux');

if (isset($_GET['mailAddresses1'])) { // 验证用户是否已经存在
	$trimmedMailAddress = preg_replace("/(\s+)/",'',$_GET['mailAddresses1']); // 去掉所有空格
	$mailAddress = explode(',', $trimmedMailAddress); // 分别取得所有邮件地址
	foreach($mailAddress as $mail) {
		$result = mysql_query("select * from xy_member where member_name = '" . $mail . "'");
		$row = mysql_fetch_array($result);
		if ($row) {
			echo '成员' . "<font color='red'>" . $mail . '</font>已经存在！';
			exit;
		}
	}
	if (!$_GET['mailAddresses1'] == "") { // 防止提交空文本
		echo '以上成员尚未添加！';
	}
} // end of if

mysql_close($dbLink);
?>