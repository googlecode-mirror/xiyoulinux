<?php
/*
Plugin Name: 成员管理
Plugin URI: http://www.baidu.com
Version: 1.00
Author: Johnson Wei
Description: 管理员可以在此添加、查看、删除成员。
*/


global $count;
$count = 0;
if (!class_exists("UpdateMemberList")) { 
	class UpdateMemberList {
		var $adminOptionsName = 'SMTPSettings';
		var $devOptions_bak;
		function UpdateMemberList() {}
		
		public function init() {  // 初始化函数
			$this->getSMTPOptions();
		}
		
		function __toString()
		{
		    return "";
		}
			
		public function registerAJAX() { // 载入AJAX
			wp_enqueue_script('validate_username', WP_PLUGIN_URL  . 
			'/member_management/js/validate_user.ajax.php', array('prototype')); 
		}
		
		public function getSMTPOptions() { // 获得SMTP设置的数组
			$defaultSettings = array('UserName' => 'XiyouLinux@gmail.com',
				'Password' => 'XiyouLinux', 'From' => 'XiyouLinux@gmail.com',
				'FromName' => 'XiyouLinux');
			$devOptions = get_option($this->adminOptionsName);
			if (!empty($devOptions)) {
				foreach($devOptions as $key => $value) {
					$defaultSettings[$key] = $value;
				}
			}
			update_option($this->adminOptionsName, $defaultSettings);
			return $defaultSettings;
		} // end of getSMTPOptions
	} // end of class UpdageMemberList
} // endl of if

global $dl_uml;
$dl_uml = new UpdateMemberList(); // 实例化

function printAddMemPage() { // 输出添加新成员页面
	global $dl_uml;
	$devOptions = $dl_uml->getSMTPOptions();
		include("DB-config.php");
		include("php/print_addMem_Page.php");
	}
		
function printUpdateMailerPage() { // 输出邮件SMTP设置页面
	global $dl_uml;
	$devOptions = $dl_uml->getSMTPOptions();
	if (isset($_POST['flag'])) { // 如果提交回本页面
		if (isset($_POST['UserName'])) {
			$devOptions['UserName'] = $_POST['UserName'];
		}
		if (isset($_POST['Password'])) {
			$devOptions['Password'] = $_POST['Password'];
		}
		if (isset($_POST['From'])) {
			$devOptions['From'] = $_POST['From'];
		}
		if (isset($_POST['FromName'])) {
			$devOptions['FromName'] = $_POST['FromName'];
		}
		$dl_uml->devOptions_bak = $devOptions;
		update_option($dl_uml->adminOptionsName, $devOptions); // 更新配置值
		?>
		<div class="updated">
			<p><strong>更新已保存</strong></p>
		</div>
		<?php 
	}
	include("php/print_updateMailer_Page.php");
}
		
function printUpdateMemberPage() { // 输出成员信息管理页面
	include("DB-config.php");
	include("php/print_updateMem_Page.php");
}

if (!function_exists("addMember_ap")) { // 定义addMember_ap函数
	function addMember_ap() {
		global $dl_uml;
		if (!isset($dl_uml)) {
			return;
		}
		if (function_exists("add_menu_page")) {
			add_menu_page("成员管理", "成员管理", 5,
				"handle1", "printUpdateMemberPage");
		}
		if (function_exists('add_submenu_page')) {
			add_submenu_page('handle1', "添加新成员", '添加新成员', 3,
				"handle2", 'printAddMemPage');
		}
		if (function_exists('add_options_page')) {
			add_submenu_page("handle1", '邮件服务器设置', '邮件服务器设置', 9,
				"handle3", "printUpdateMailerPage");
		}
	} // end of addmember_ap
} // end of if

if (isset($dl_uml)) {
	// Actions
	register_activation_hook(__FILE__, array(&$dl_uml, 'init'));
	add_action('admin_init', array(&$dl_uml, 'registerAJAX'));	
	add_action('admin_menu', 'addMember_ap');
}
?>