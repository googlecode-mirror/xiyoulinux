<?php

define('XY_ALBUM_VERSION', '1.2.0');
define('BASEDIR', dirname(__FILE__));
define('XY_ALBUM_DIR','xy_album_'.XY_ALBUM_VERSION)

?>
