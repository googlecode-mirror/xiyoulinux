<?php

define('XY_ALBUM_VERSION', ' 1.0');
define('BASEDIR', dirname(__FILE__));

?>
