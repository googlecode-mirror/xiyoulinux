function xy_print()
{
	alert("Hello World!");
}
