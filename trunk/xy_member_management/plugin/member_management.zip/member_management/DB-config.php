<?php 
/*
 * File Name:	DB-config.php
 * Author:		Johnson
 * Version:		v1.00
 * Description:	定义MySQL数据库的server，username，password。若数据库这三个参数有变动，修改此配置文件。
 */

$server   = "localhost";
$userName = "root";
$password = "";
?>