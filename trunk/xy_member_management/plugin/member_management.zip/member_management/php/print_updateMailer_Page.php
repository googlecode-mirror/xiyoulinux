<?php
/*
 * File Name:	print_updateMailer_Page.php
 * Author:		Johnson Wei
 * Version:		1.10
 * Description: 修改邮件发送服务器参数
 */
?>
<div class=wrap>
	<div class="icon32" id="icon-options-general"><br/></div>
	<h2>邮件服务器设置(Gmail)</h2>
	<br/>
	<form name="form2" action="<?php echo $_SERVER['REQUEST_URI'] ?>" method="post">
		<input type="hidden" name="flag"/>
		<table class="form-table">
			<tr>
				<th><label>用户名</label></th>
				<td><input type="text" name="UserName" size="50" value="<?php echo $devOptions['UserName'];?>"/>
				<font color="color">&nbsp;&nbsp;格式: example@gmail.com</font></td>
			</tr>
			<tr>
				<th><label>密码</label></th>
				<td><input type="password" name="Password"  size="50" value="<?php echo $devOptions['Password']?>"/></td>
			</tr>
			<tr>
				<th><label>确认密码</label></th>
				<td><input type="password" size="50" name="Password_Confirm"/>
				<font color="color">&nbsp;&nbsp;若不修改密码，则不需填写</font></td>
			</tr>
			<tr>
				<th><label>发件人地址</label></th>
				<td><input type="text" name="From" size="50" value="<?php echo $devOptions['From'];?>"/>
				<font color="color">&nbsp;&nbsp;格式: example@gmail.com</font></td>
			</tr>
			<tr>
				<th><label>发件人姓名</label></th>
				<td><input type="text" name="FromName" size="50" value="<?php echo $devOptions['FromName'];?>"/></td>
			</tr>
		</table>
		<br/>
		<div class="submit">
			<input type="button" class="button-primary" value="提交更改" onclick="check()"/>
		</div>
	</form>
</div>