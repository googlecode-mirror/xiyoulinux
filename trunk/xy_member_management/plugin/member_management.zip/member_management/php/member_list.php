<?php 
if (isset($_REQUEST["hidden"])) { // 打印成员列表页面
		$modify = $_REQUEST['modify'];
		if (is_array($modify)) {
			foreach($modify as $key) {
				mysql_query("delete from xy_member where member_name = '" . $key . "'");
			}
		} else {
			mysql_query("delete from xy_member where member_name = '" . $modify . "'");
		}
	}
	$result = mysql_query("select * from xy_member");
	$count = 1;
?>
<div class="wrap">
<div id="icon-users" class="icon32"><br /></div>
<h2>成员管理 <a href="admin.php?page=handle2" class="button add-new-h2">添加新成员</a> </h2>
<form action="<?php echo $_SERVER['REQUEST_URI']?>" name="form3" method="post">
<input type="hidden" name="hidden"/>
<div class="tablenav">
		<div class="alignleft actions">
		<select name="action2">
		<option value="" selected="selected">批量动作</option>
		<option value="delete">删除</option>
		</select>
		<input type="button" value="应用" name="doaction2" id="doaction2" class="button-secondary action" onclick="checkSelect()"/>
		</div>
		<br class="clear" />
</div>
<table class="widefat fixed" cellspacing="0">
	<thead>
		<tr class="thead">
			<th scope="col" id="cb" class="manage-column column-cb check-column" style="">
			<input name="all" onclick="check_all(this,'modify[]')" type="checkbox" /></th>
			<th scope="col" id="posts" class="manage-column column-posts num" style="">序号</th>
			<th scope="col" id="username" class="manage-column column-username" style="">登录名</th>
			<th scope="col" id="name" class="manage-column column-name" style="">真实姓名</th>
			<th scope="col" id="name" class="manage-column column-name" style="">手机</th>
			<th scope="col" id="comment" class="manage-column column-comment" style="">专业</th>
		</tr>
	</thead>
	<tbody id="users" class="list:user user-list">
		<?php
			$pagesize = 10;  //定义每页显示多少条记录
			$page = isset($_GET["page1"])?intval($_GET["page1"]):1;   		  //定义page的初始值,如果get 传过来的page为空,则page=1,
			$total = mysql_num_rows(mysql_query("select * from xy_member"));  //执行查询获取总记录数
			$pagecount = ceil($total / $pagesize);  //计算出总页数
			if ($page > $pagecount){
				$page = $pagecount;  // 对提交过来的page做一些检查
			}
			if ($page <= 0) {
				$page = 1;                   // 对提交过来的page做一些检查
			}
			$offset = ($page-1) * $pagesize; //偏移量
			$pre = $page-1;        //上一页
			$next = $page+1;       //下一页
			$first = 1;            //第一页
			$last = $pagecount;    //末页
			$exec = "select * from xy_member order by member_id asc limit $offset , $pagesize"; //执行查询
			$result = mysql_query($exec);
			while ($row = mysql_fetch_array($result)){  //循环出记录
			?>
				<tr>
					<th scope='row' class='check-column'><input type="checkbox" name="modify[]" value="<?php echo $row['member_name']?>"/></th>
					<th  class="posts column-posts num"><?php echo $count++;?></th>
					<th><a href="admin.php?page=handle1&detail=&member_name=<?php echo $row['member_name']?>">
						<?php echo $row['member_name']?></a>
					<div class="row-actions"><span class='edit'>
					<a href="#">编辑</a> | </span><span class='delete'>
					<a class='submitdelete' href="admin.php?page=handle1&hidden=&modify=<?php echo $row['member_name']?>">删除</a>
					</span></div></th>
					<td><?php echo $row['member_nickname']?></td><td><?php echo $row['member_mobile']?></td>
					<td><?php echo $row['member_major']?></td>
				</tr>
			<?php 	
			}	
		?>
	</tbody>
	<tfoot>
		<tr class="thead">
			<th scope="col" class="manage-column column-cb check-column" style="">
			<input name="all" onclick="check_all(this,'modify[]')" type="checkbox" /></th>
			<th scope="col" class="manage-column column-posts num" style="">序号</th>
			<th scope="col" class="manage-column column-username" style="">登录名</th>
			<th scope="col" class="manage-column column-name" style="">真实姓名</th>
			<th scope="col" class="manage-column column-name" style="">手机</th>
			<th scope="col" class="manage-column column-comment" style="">专业</th>
		</tr>
	</tfoot>
	</table>
	<div class="tablenav">
		<div class="alignleft actions">
		<select name="action2">
		<option value="" selected="selected">批量动作</option>
		<option value="delete">删除</option>
		</select>
		<input type="button" value="应用" name="doaction2" id="doaction2" class="button-secondary action" onclick="checkSelect()"/>
		</div>
		<br class="clear" />
	</div>
</form>
共<?php echo $total?>条记录&nbsp;&nbsp;
<?php echo $page?>/<?php echo $pagecount?>&nbsp;&nbsp;
<a href="<?php echo $_SERVER['REQUEST_URI'];?>&page1=1">首页</a>|
<a href="<?php echo $_SERVER['REQUEST_URI'];?>&page1=<?php echo $pre?>">上一页</a>|
<a href="<?php echo $_SERVER['REQUEST_URI'];?>&page1=<?php echo $next?>">下一页</a>|
<a href="<?php echo $_SERVER['REQUEST_URI'];?>&page1=<?php echo $last?>">末页</a>
</div>