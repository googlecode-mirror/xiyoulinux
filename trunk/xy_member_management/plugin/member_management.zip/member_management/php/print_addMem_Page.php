<?php
/*
 * File Name:	print_addMem_Page.php
 * Author:		Johnson Wei
 * Version:		1.10
 * Description: 管理员通过邮件来发送密码
 */

require_once("mailer.php");

function getRandom() { // 获得随机数
	$str = "0123456789abcdefghijklmnopqrstuvwxyz";
	$n = 5;
	$len = strlen($str)-1;
	for($i=0 ; $i<$n; $i++)
		$s .= $str[rand(0, $len)];
	return $s;
}

if ($_POST['addMemContent']) { // 如果提交
	
	$trimmedMailAddress = preg_replace("/(\s+)/",'',$_POST['addMemContent']);
	$mailAddress = explode(',', $trimmedMailAddress);	
	$SMTPSettings = $devOptions;
	$Subject = "请牢记您的登陆密码";
	$prefix = "xy_";
	$pwd = "";
	
	if (isset($server)) { // 数据库文件载入成功
		$con = mysql_connect($server, $userName, $password);
		if (!$con) {
			die("数据库连接失败！" . mysql_error());
		}
		mysql_query("set names 'utf8'");
		mysql_select_db("xiyoulinux");
	} else {
		echo "DB-config.php引入失败！";
		exit;
	}
	foreach($mailAddress as $mail) {
		$tmpPwd = $prefix . getRandom();
		$Body = $mail . " 你好！ 请牢记你的登陆密码： <font color='red'>" . $tmpPwd . "</font> 。此邮件请勿回复！";		
		$result = mysql_query("select * from xy_member where member_name = '" . $mail . "'");
		$row = mysql_fetch_array($result);
		if ($row) {
			?>
			<div class="updated">
				<p><strong><font color='red'>该成员已经存在！</font></strong></p>
				<a href="javascript:history.back(-1)">返回</a>
			</div>
			<?php 
			exit;
		} else {
			$flag = mysql_query("insert into xy_member(member_name, member_pwd) 
				values('" . $mail . "', '" . $tmpPwd . "')");
			if (mysql_affected_rows() != 1) {
			?>
			<div class="updated">
				<p><strong><font color='red'>插入数据异常！</font></strong></p>
				<a href="javascript:history.go(-1);">返回</a>
			</div>
			<?php 
			exit;
			}
			$pwd .= $tmpPwd . "  ";
		}
		$result = phpMailer($SMTPSettings['UserName'], $SMTPSettings['Password'], $SMTPSettings['From'], 
				$SMTPSettings['FromName'], $Body, $mail, $Subject);
		if ($result[0] == 0) {
			exit;
		}
	}
	?>
	<div class="updated">
		<p><strong>
			邮件发送成功!<br/><br/>
			<font color="red">生成密码是: <?php echo $pwd ?></font>
		</strong></p>
	</div>
<?php 
mysql_close($con);
}
?>

<div class=wrap>
	<div id="icon-users" class="icon32"><br /></div>
	<h2>添加新成员&nbsp;<a href="admin.php?page=handle3" class="button add-new-h2">设置SMTP</a></h2>
	<br />
	<h3>在下面填写要添加成员的邮箱<!-- ，<font color="red">用逗号分隔</font> --></h3>
	<form name="form1" action="<?php echo $_SERVER['REQUEST_URI']?>" method="post">
<!-- 		<textarea name="addMemContent" style="width:50%; height:100px;">
		</textarea> -->
		<input type="text" name="addMemContent" />
		<br />
		<span id="txtHint"></span>
		<br/>
		<div class="submit">
			<input type="button" class="button-primary" onclick="ajaxFunction(document.form1.addMemContent.value, 'mailAddresses1')" 
				value="检查用户是否已存在"/>&nbsp;&nbsp;&nbsp;
			<input type="button" class="button-primary" onclick="sendEmail()"	value="发送邮件"/>
		</div>
	</form>
</div>