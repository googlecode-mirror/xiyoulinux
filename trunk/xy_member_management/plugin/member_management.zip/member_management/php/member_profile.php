<?php
/*
 * File Name:	profile.php
 * Author:		Johnson Wei
 * Version:		1.00
 * Description:	查看、修改成员详细信息。
 */

// 找出数据库中的头像存储路径
if (isset($_GET["member_name"])) {
	$result = mysql_query("select * from xy_member where member_name = '" . $_GET["member_name"] . "'");
	$row = mysql_fetch_array($result);
	$userImg = $row["member_image"];
	// 执行Js调整图片大小
	echo "<script>goto('" . $userImg . "')</script>";
}
if (isset($_POST['submit'])) { // 如果提交
	$sql = "update xy_member set member_nickname = '" . $_POST['member_nickname'] . "', 
		member_email = '" . $_POST['member_email'] . "', member_blog = '" . $_POST['member_blog'] . "',
		member_rss_url = '" . $_POST['member_rss_url'] . "', member_QQ = '" . $_POST['member_QQ'] . "',
		member_mobile = '" . $_POST['member_mobile'] . "', member_major = '" . $_POST['member_major'] . "',
		member_pwd = '" . $_POST['member_pwd'] . "' where member_name = '" . $_POST['member_name'] . "'";
	mysql_query($sql); // 执行sql
	$row = array("member_name" => $_POST['member_name'], "member_nickname" => $_POST['member_nickname'],
				 "member_email" => $_POST["member_email"], "member_rss_url" => $_POST["member_rss_url"],
				 "member_QQ" => $_POST["member_QQ"], "member_mobile" => $_POST["member_mobile"],
				 "member_major" => $_POST["member_major"], "member_pwd" => $_POST["member_pwd"],
				 "member_blog" => $_POST["member_blog"]);
	?>
	<div class="updated">
		<p><strong>更新已保存</strong></p>
	</div>
<?php 
}
?>
<div class="wrap" id="profile-page">
	<div id="icon-users" class="icon32"><br /></div>
	<h2>详细信息</h2>
	<form name="form4" id="your-profile" action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post">
		<input type="hidden" name="detail"/>
		<input type="hidden" name="submit"/>
		<table class="form-table">
			<tr>
				<th><label>头像</label></th>
				<td><img id="showImg" alt="Image"/></td>
			</tr>
			<tr>
				<th><label>用户名</label></th>
				<td><input type="text" name="member_name"  size="50" value="<?php echo $row['member_name'];?>" readonly="readonly"/>
					&nbsp;&nbsp;<font color="red">用户名不能修改</font>
				</td>
			</tr>
			<tr>
				<th><label>真实姓名</label></th>
				<td><input type="text"  name="member_nickname" size="50" value="<?php echo $row['member_nickname']?>"/></td>
			</tr>
			<tr>
				<th><label>其他Email</label></th>
				<td><input type="text" size="50" name="member_email"  value="<?php echo $row['member_email']?>"/></td>
			</tr>
			<tr>
				<th><label>博客</label></th>
				<td><input type="text" size="50" name="member_blog"  value="<?php echo $row['member_blog']?>"/></td>
			</tr>
			<tr>
				<th><label>RSS订阅</label></th>
				<td><input type="text" size="50" name="member_rss_url" value="<?php echo $row['member_rss_url'];?>"/></td>
			</tr>
			<tr>
				<th><label>QQ</label></th>
				<td><input type="text"  size="50" name="member_QQ" value="<?php echo $row['member_QQ'];?>"/></td>
			</tr>
			<tr>
				<th><label>手机</label></th>
				<td><input type="text" size="50" name="member_mobile" value="<?php echo $row['member_mobile']?>"/></td>
			</tr>
			<tr>
				<th><label>专业</label></th>
				<td><input type="text"  size="50" name="member_major" value="<?php echo $row['member_major']?>"/></td>
			</tr>
			<tr>
				<th><label>密码</label></th>
				<td><input type="text" size="50" name="member_pwd" value="<?php echo $row['member_pwd']?>"/></td>
			</tr>
		</table>
		<p class="submit">
			<input type="submit" class="button-primary" value="更新配置"/>
		</p>
	</form>
</div>
