<?php
/*
 * File Name:	mailer.php
 * Author:		Johnson Wei
 * Version:		1.00
 * Description:	这个文件是负责邮件发送，调用了外部类：class.phpmailer.php
 */ 
function phpMailer($UserName, $Password, $From, $FromName, $Body, $AddAddress, $Subject) {
	date_default_timezone_set('UTC');
	include("class.phpmailer.php");
	include("class.smtp.php"); // note, this is optional - gets called from main class if not already loaded
	
	$mail             = new PHPMailer();
	$mail->IsSMTP();
	$mail->SMTPAuth   = true;                  // enable SMTP authentication
	$mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
	$mail->Host       = "smtp.gmail.com";      // sets GMAIL as the SMTP server
	$mail->Port       = 465;                   // set the SMTP port
	
	$mail->Username   = $UserName;  // GMAIL username
	$mail->Password   = $Password;            // GMAIL password
	
	$mail->From       = $From;
	$mail->FromName   = $FromName;
	$mail->Subject    = $Subject;
	$mail->AltBody    = "看到这则消息后，说明您的浏览器不支持HTML浏览，请使用支持HTML的Email浏览！"; //Text Body
	$mail->WordWrap   = 50; // set word wrap
	
	$mail->Body = $Body; 
	
//	$mail->AddReplyTo("","");	// 不需要回复
	
	$mail->AddAddress($AddAddress);	// Address of the receiver:Only this is different!
	
	$mail->IsHTML(true); // send as HTML
	
	$mail->CharSet = "UTF-8";
	
	if(!$mail->Send()) {
		return array(0, $mail->ErrorInfo);
	} else {
		return array(1);
	}
} // end of function
?>
