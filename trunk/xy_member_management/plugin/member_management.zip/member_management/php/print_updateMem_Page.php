<?php
/*
 * File Name:	print_updateMem_Page.php
 * Author:		Johnson Wei
 * Version:		1.10
 * Description:	输出成员信息列表，点击每个成员的用户名还可以修改其详细信息
 */

$con = mysql_connect($server, $userName, $password);
if (!$con) {
	die("数据库连接失败" . mysql_error());
}
mysql_query("set name 'utf8'");
mysql_select_db("xiyoulinux");

if (isset($_REQUEST["detail"])) { // 打印成员详细信息页面
	include("member_profile.php");	
} else {
	include("member_list.php");
}
mysql_close($con);   //关闭数据库连接 
?>
