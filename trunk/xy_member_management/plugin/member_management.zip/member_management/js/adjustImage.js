var aImg = new Image();
var photo_width, photo_height;
var srcPath;
var preSize = 180; // 尺寸不能超过200 * 200
var maxSize = 512 * 1000; // 最大为512KB
function getSize() {   
	if (aImg.readyState == "complete") {
		if (aImg.width > preSize) { // 调整图片尺寸
			photo_width = preSize;   
			photo_height = preSize * (aImg.height / aImg.width);   
			aImg.height = photo_height;
			aImg.width = photo_width;
		}
		if (aImg.height > preSize) {
			photo_height = preSize;
			photo_width = preSize * (aImg.width / aImg.height);
		}    
		document.getElementById("showImg").src = srcPath;
		document.getElementById("showImg").width = photo_width;
		document.getElemtntById("shwoImg").height = photo_height;
	} else {
  		setTimeout("getSize()","100");   
  	}
}

function goto(path) {
	srcPath = path;
	aImg.src = srcPath;   
	getSize();   
}