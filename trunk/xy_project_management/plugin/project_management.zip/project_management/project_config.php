<?php
	define('project_table_name', 'xy_project');
	define('project_path', dirname(__FILE__));
	define('project_images_path', '');
?>
