<?php
/*
-----------------------------------------------------
xiyoulinux MediaWiki skin
www.xiyoulinux.cn

DO NOT REMOVE THE LINK-BACKS TO THE xiyoulinux SITE!
-----------------------------------------------------
*/
require_once('includes/SkinTemplate.php');
?>
